DROP DATABASE IF EXISTS Ferme;
CREATE DATABASE Ferme;
USE Ferme;



-- Table Utilisateur
CREATE TABLE Utilisateur (
    id_utilisateur INT PRIMARY KEY AUTO_INCREMENT,
    prenom VARCHAR(100) NOT NULL,
    nom VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    tel VARCHAR(20) NOT NULL,
    login VARCHAR(100) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    adresse VARCHAR(255),
    photo VARCHAR(255)
);

-- Table Woofer qui hérite de Utilisateur
CREATE TABLE Woofer (
    id_woofer INT PRIMARY KEY,
    date_arrivee DATE NOT NULL,
    date_depart DATE NOT NULL,
    FOREIGN KEY (id_woofer) REFERENCES Utilisateur(id_utilisateur) ON DELETE CASCADE
);

-- Table Responsable qui hérite de Utilisateur
CREATE TABLE Responsable (
    id_responsable INT PRIMARY KEY,
    FOREIGN KEY (id_responsable) REFERENCES Utilisateur(id_utilisateur) ON DELETE CASCADE
);

-- Table Catégorie
CREATE TABLE Categorie (
    id_categorie INT PRIMARY KEY AUTO_INCREMENT,
    nom_categorie TEXT NOT NULL UNIQUE
);

-- Table Produit
CREATE TABLE Produit (
    id_produit INT PRIMARY KEY AUTO_INCREMENT,
    intitule_produit TEXT NOT NULL,
    prix_unitaire_produit DECIMAL(10,2) NOT NULL,
    photo_produit VARCHAR(255),
    quantite_stock INT NOT NULL DEFAULT 0,
    etat_produit ENUM('Disponible', 'Indisponible') NOT NULL,
    id_categorie INT,
    FOREIGN KEY (id_categorie) REFERENCES Categorie(id_categorie) ON DELETE SET NULL
);

-- Table Vente
CREATE TABLE Vente (
    id_vente INT PRIMARY KEY AUTO_INCREMENT,
    id_utilisateur INT,
    etat_vente ENUM('Enregistrée', 'Annulée', 'EnCours') NOT NULL,
    date_vente DATE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_utilisateur) REFERENCES Utilisateur(id_utilisateur) ON DELETE SET NULL
);

-- Table Ticket
CREATE TABLE Ticket (
    id_ticket INT PRIMARY KEY AUTO_INCREMENT,
    date_ticket DATE NOT NULL,
    total_HT DECIMAL(10,2) NOT NULL,
    TVA DECIMAL(10,2) NOT NULL,
    id_vente INT,
    FOREIGN KEY (id_vente) REFERENCES Vente(id_vente) ON DELETE CASCADE
);

-- Table Atelier
CREATE TABLE Atelier (
    id_atelier INT PRIMARY KEY AUTO_INCREMENT,
    nom_atelier TEXT NOT NULL,
    prix_atelier DECIMAL(10,2) NOT NULL,
    id_categorie INT,
    FOREIGN KEY (id_categorie) REFERENCES Categorie(id_categorie) ON DELETE SET NULL
);

-- Table Session
CREATE TABLE Session (
    id_session INT PRIMARY KEY AUTO_INCREMENT,
    date_session DATETIME NOT NULL,
    etat_session ENUM('Reprogrammée', 'Annulée', 'En cours','Terminée','Programmée') NOT NULL,
    numero_session INT NOT NULL,
    id_atelier INT,
    FOREIGN KEY (id_atelier) REFERENCES Atelier(id_atelier) ON DELETE SET NULL
);

-- Table Participant
CREATE TABLE Participant (
    id_participant INT PRIMARY KEY AUTO_INCREMENT,
    prenom VARCHAR(100) NOT NULL,
    nom VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    tel VARCHAR(20) NOT NULL
);

-- Table Tâche
CREATE TABLE Tache (
    id_tache INT PRIMARY KEY AUTO_INCREMENT,
    intitule_tache TEXT NOT NULL,
    duree_tache TIME NOT NULL,
    etat_tache ENUM('A réaliser', 'Terminée', 'En cours') NOT NULL,
    jour VARCHAR(20) NOT NULL
);

-- Table d'association Vente_Produit
CREATE TABLE Vente_Produit (
    id_vente INT,
    id_produit INT,
    quantite_vendue INT NOT NULL,
    PRIMARY KEY (id_vente, id_produit),
    FOREIGN KEY (id_vente) REFERENCES Vente(id_vente) ON DELETE CASCADE,
    FOREIGN KEY (id_produit) REFERENCES Produit(id_produit) ON DELETE CASCADE
);

-- Table d'association Session_Woofer
CREATE TABLE WooferAnimeSession (
    id_woofer INT,
    id_session INT,
    PRIMARY KEY (id_woofer, id_session),
    FOREIGN KEY (id_woofer) REFERENCES Woofer(id_woofer) ON DELETE CASCADE,
    FOREIGN KEY (id_session) REFERENCES Session(id_session) ON DELETE CASCADE
);

-- Table d'association Tache_Woofer
CREATE TABLE WooferFaitTache (
    id_woofer INT,
    id_tache INT,
    PRIMARY KEY (id_woofer, id_tache),
    FOREIGN KEY (id_woofer) REFERENCES Woofer(id_woofer) ON DELETE CASCADE,
    FOREIGN KEY (id_tache) REFERENCES Tache(id_tache) ON DELETE CASCADE
);

-- Table d'association Session_Participant
CREATE TABLE ParticipantSession (
    id_participant INT,
    id_session INT,
    estValidé BOOLEAN DEFAULT FALSE,
    PRIMARY KEY (id_participant, id_session),
    FOREIGN KEY (id_participant) REFERENCES Participant(id_participant) ON DELETE CASCADE,
    FOREIGN KEY (id_session) REFERENCES Session(id_session) ON DELETE CASCADE
);

-- Table Compétence (Nouvelles compétences possibles)
CREATE TABLE Competence (
    id_competence INT PRIMARY KEY AUTO_INCREMENT,
    nom_competence TEXT NOT NULL UNIQUE
);

-- Table associative entre Woofer et Compétence
CREATE TABLE WooferPossedeCompetence (
    id_woofer INT,
    id_competence INT,
    PRIMARY KEY (id_woofer, id_competence),
    FOREIGN KEY (id_woofer) REFERENCES Woofer(id_woofer) ON DELETE CASCADE,
    FOREIGN KEY (id_competence) REFERENCES Competence(id_competence) ON DELETE CASCADE
);

SET GLOBAL event_scheduler = ON;

DELIMITER //

CREATE EVENT suppr4ans
ON SCHEDULE EVERY 1 DAY
DO
BEGIN
    DELETE FROM Ticket WHERE date_ticket < DATE_SUB(CURDATE(), INTERVAL 4 YEAR);

    DELETE FROM Vente WHERE date_vente < DATE_SUB(CURDATE(), INTERVAL 4 YEAR);

    DELETE FROM Session WHERE date_session < DATE_SUB(CURDATE(), INTERVAL 4 YEAR);

    DELETE FROM Participant
    WHERE id_participant NOT IN (
        SELECT DISTINCT sp.id_participant
        FROM participantsession sp
        JOIN Session s ON sp.id_session = s.id_session
        WHERE s.date_session >= DATE_SUB(CURDATE(), INTERVAL 4 YEAR)
    );

    DELETE FROM Utilisateur
    WHERE id_utilisateur IN (
        SELECT w.id_woofer FROM Woofer w
        WHERE w.date_depart < DATE_SUB(CURDATE(), INTERVAL 4 YEAR)
    );

    DELETE FROM Woofer WHERE date_depart < DATE_SUB(CURDATE(), INTERVAL 4 YEAR);

END //

DELIMITER ;
-- Création des triggers
DELIMITER //
CREATE TRIGGER generate_ticket_on_sale
AFTER INSERT ON Vente
FOR EACH ROW
BEGIN
    INSERT INTO Ticket (date_ticket, id_vente, total_HT, TVA)
    VALUES (NEW.date_vente, NEW.id_vente, 0, 0);
END //

CREATE TRIGGER updateTicketStock
AFTER INSERT ON Vente_Produit
FOR EACH ROW
BEGIN
    DECLARE vente_etat VARCHAR(20);

    -- Récupérer l'état de la vente
    SELECT etat_vente INTO vente_etat
    FROM Vente
    WHERE id_vente = NEW.id_vente;

    IF vente_etat != 'EnCours' AND vente_etat != 'Annulée' THEN
        CALL venteProduit(NEW.id_produit, NEW.quantite_vendue);
    END IF;

    UPDATE Ticket t
    SET t.total_HT = (
        SELECT SUM(p.prix_unitaire_produit * vp.quantite_vendue)
        FROM Vente_Produit vp
        JOIN Produit p ON vp.id_produit = p.id_produit
        WHERE vp.id_vente = t.id_vente
    ),
    t.TVA = (t.total_HT * 0.2) -- Applique une TVA de 20%
    WHERE t.id_vente = NEW.id_vente;
END //

CREATE TRIGGER updateEtatProduit
AFTER UPDATE ON Produit
FOR EACH ROW
BEGIN
    IF NEW.quantite_stock = 0 THEN
        UPDATE Produit
        SET etat_produit = 'Indisponible'
        WHERE id_produit = NEW.id_produit;
    END IF;
END//

-- Création des procédures

CREATE PROCEDURE miseEnStock(
    IN p_id_produit INT,
    IN p_quantite INT
)
BEGIN
    UPDATE Produit
    SET quantite_stock = quantite_stock + p_quantite
    WHERE id_produit = p_id_produit;
END//

CREATE PROCEDURE venteProduit(
    IN p_id_produit INT,
    IN p_quantite_vendue INT
)
BEGIN
    DECLARE stock_actuel INT;

    -- Récupérer le stock actuel du produit
    SELECT quantite_stock INTO stock_actuel FROM Produit WHERE id_produit = p_id_produit;

    -- Vérifier si le stock est suffisant
    IF stock_actuel >= p_quantite_vendue THEN
        -- Déduire la quantité du stock
        UPDATE Produit
        SET quantite_stock = quantite_stock - p_quantite_vendue
        WHERE id_produit = p_id_produit;
    ELSE
        -- Générer une erreur si le stock est insuffisant
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Stock insuffisant pour effectuer cette vente';
    END IF;
END//


CREATE PROCEDURE commencerSession(
    IN p_id_session INT
)
BEGIN
    UPDATE Session
    SET etat_session = 'En cours'
    WHERE id_session = p_id_session;
END//

CREATE PROCEDURE terminerSession(
    IN p_id_session INT
)
BEGIN
    UPDATE Session
    SET etat_session = 'Terminée'
    WHERE id_session = p_id_session;
END//

CREATE PROCEDURE annulerSession(
    IN p_id_session INT
)
BEGIN
    UPDATE Session
    SET etat_session = 'Annulée'
    WHERE id_session = p_id_session;
END//

CREATE PROCEDURE repousserSession(
    IN p_id_session INT,
    IN dateRepousse DATE
)
BEGIN
    UPDATE Session
    SET date_session = dateRepousse,
        etat_session = 'Reprogrammée'
    WHERE id_session = p_id_session;
END//

CREATE PROCEDURE debutTache(
    IN p_id_tache INT
)
BEGIN
    UPDATE Tache
    SET etat_tache = 'En cours'
    WHERE id_tache = p_id_tache;
END//

CREATE PROCEDURE finTache(
    IN p_id_tache INT
)
BEGIN
    UPDATE Tache
    SET etat_tache = 'Terminée'
    WHERE id_tache = p_id_tache;
END//
DELIMITER ;
-- Insertion de données
-- Insertion des utilisateurs
INSERT INTO Utilisateur (prenom, nom, email, tel, login, mot_de_passe, adresse, photo) VALUES
('Alice', 'Dupont', 'alice.dupont@email.com', '0601020304', 'alice123', '$2y$10$XbUAk81QxwmSfVdY5gnc1uC430Asf9yG3OFClsyUangXK5sNHgghm',  '123 Rue des Champs', 'alice_dupont.jpg'),
('Bob', 'Martin', 'bob.martin@email.com', '0602030405', 'bob456', '$2y$10$kW66ujYONutqbpeAEC7fku5b6DlTCHa7JjOC6ZWTllw3gFwa83876',  '456 Rue du Verger', 'bob_martin.jpg'),
('Charlie', 'Durand', 'charlie.durand@email.com', '0603040506', 'charlie789', '$2y$10$t/klkAVKfyiDLtCY5FfNguuHsgoz46dRebQLIbewyPiW5Uc2n0Z1q',  '789 Rue des Vignes', 'charlie_durand.png'),
('David', 'Lemoine', 'david.lemoine@email.com', '0604050607', 'david101', '$2y$10$Q/UT/NprJpiqoBEnccQ87.sXbSBuU7PUpZx2xSaLjQ.pTzlOQ5r2.',  '101 Rue des Prés', 'david_lemoine.jpg'),
('Emma', 'Morel', 'emma.morel@email.com', '0605060708', 'emma202', '$2y$10$mr.Ry2ZwM2pa0kIcU7qYQuC2Ey2DjDHFiU9LmNrhBMwKk2B9H9XIS',  '202 Rue des Pommiers', 'emma_morel.jpg'),
('Fanny', 'Bertrand', 'fanny.bertrand@email.com', '0606070809', 'fanny303', '$2y$10$vINxWq0koaULu1zNJrCXEu054IbF7hQplFcefvSnZzz1jGuiyIH06',  '303 Rue des Chênes', 'fanny_bertrand.jpg'),
('Georges', 'Lambert', 'georges.lambert@email.com', '0607080910', 'georges404', '$2y$10$p3sW59pnfau4J/ZGieNn1.KdAXouDbdhj/i0nR9PiWNxeU7yjtrki', '404 Rue des Sapins', 'georges_lambert.jpg');

-- Insertion des participants
INSERT INTO Participant (prenom, nom, email, tel) VALUES
('Hugo', 'Mercier', 'hugo.mercier@email.com', '0608091011'),
('Isabelle', 'Giraud', 'isabelle.giraud@email.com', '0609101112'),
('Jean', 'Roche', 'jean.roche@email.com', '0610111213'),
('Louise', 'Moreau', 'louise.moreau@email.com', '0611121314'),
('Nicolas', 'Blanc', 'nicolas.blanc@email.com', '0612131415');

INSERT INTO Woofer (id_woofer, date_arrivee, date_depart) VALUES

(2, '2025-03-01', '2025-04-01'),
(3, '2025-03-01', '2025-04-01'),
(4, '2025-03-01', '2025-04-01'),
(5, '2025-02-01', '2025-03-01'),
(6, '2024-01-01', '2025-02-01');


INSERT INTO Categorie (nom_categorie) VALUES
('Fruits et Légumes'),
('Produits laitiers'),
('Ingrédients'),
('Viande');

INSERT INTO Produit (intitule_produit, prix_unitaire_produit, photo_produit, quantite_stock, etat_produit, id_categorie) VALUES
('Pommes rouges bio', 2.50,'pommes_rouges.jpg', 100, 'Disponible', 1),
('Pommes de terre', 1.20,'pommes_de_terre.jpg', 150, 'Disponible', 1),
('Lait de vache', 1.50,'lait.jpg', 80, 'Disponible', 2),
('Fromage', 4.00,'Fromage.jpg', 50, 'Disponible', 2),
('Oeufs de poules', 3.00,'oeufs.jpg', 120, 'Disponible', 3);

INSERT INTO Responsable (id_responsable) VALUES (1), (7);

INSERT INTO Vente (date_vente,id_utilisateur,etat_vente) VALUES
('2025-03-01',2,'Enregistrée'),
('2025-03-07',3,'Annulée'),
('2025-03-10',1,'Enregistrée'),
('2025-03-11',3,'EnCours'),
('2025-03-11',5,'Enregistrée');

INSERT INTO Vente_Produit (id_vente, id_produit, quantite_vendue) VALUES
(1, 1, 10), -- Vente 1 : 10 Pommes
(1, 2, 5),  -- Vente 1 : 5 Pommes de terre
(2, 3, 8),  -- Vente 2 : 8 Litres de Lait
(2, 4, 3),  -- Vente 2 : 3 Fromages
(3, 5, 12), -- Vente 3 : 12 Oeufs
(3, 1, 6),  -- Vente 3 : 6 Pommes
(4, 2, 7),  -- Vente 4 : 7 Pommes de terre
(4, 3, 4),  -- Vente 4 : 4 Litres de Lait
(5, 4, 2),  -- Vente 5 : 2 Fromages
(5, 5, 15); -- Vente 5 : 15 Oeufs

INSERT INTO Atelier (nom_atelier, prix_atelier, id_categorie) VALUES
('Atelier Fromage Maison', 1.00, 2),
('Atelier Maraîchage', 2.00, 1),
('Atelier Pain Artisanal', 1.00, 3),
('Atelier Soins aux Animaux', 2.00, 1);

INSERT INTO Session (date_session, etat_session, numero_session, id_atelier) VALUES
('2025-03-01 14:30:00', 'Terminée', 101, 1),
('2025-03-07 15:00:00', 'Terminée', 102, 2),
('2025-03-11 10:00:00', 'En cours', 103, 3),
('2025-03-15 13:30:00', 'Programmée', 104, 4);

INSERT INTO Tache (intitule_tache, duree_tache, etat_tache, jour) VALUES
('Récolte des pommes', '02:00:00', 'Terminée', 'Lundi'),
('Plantation de légumes', '03:00:00', 'Terminée', 'Mardi'),
('Soins aux animaux', '01:30:00', 'A réaliser', 'Mercredi'),
('Préparation du fromage', '02:45:00', 'A réaliser', 'Jeudi'),
('Entretien du potager', '02:00:00', 'A réaliser', 'Vendredi'),
('Collecte des œufs', '01:15:00', 'A réaliser', 'Samedi'),
('Fabrication de yaourts', '02:30:00', 'A réaliser', 'Dimanche'),
('Tri des légumes pour la vente', '01:45:00', 'En cours', 'Mardi'),
('Nettoyage des enclos', '02:15:00', 'A réaliser', 'Mercredi'),
('Préparation du marché', '02:30:00', 'A réaliser', 'Jeudi');

INSERT INTO WooferAnimeSession (id_woofer, id_session) VALUES
(2, 1), (3, 2), (4, 3), (2, 4);

INSERT INTO WooferFaitTache (id_woofer, id_tache) VALUES
(2, 1), (3, 2), (4, 3), (2, 4), (3, 5);

INSERT INTO ParticipantSession (id_participant, id_session,estValidé) VALUES
(1, 1,TRUE), (2, 2,TRUE), (3, 3,TRUE),(4, 3,FALSE),(5, 3,TRUE);

INSERT INTO Competence (nom_competence) VALUES
('Élevage de volailles'),
('Agriculture biologique'),
('Fromagerie artisanale'),
('Maraîchage'),
('Soins aux animaux'),
('Permaculture'),
('Apiculture'),
('Viticulture'),
('Fabrication de pain'),
('Gestion des cultures sous serre');

INSERT INTO WooferPossedeCompetence (id_woofer, id_competence) VALUES
-- Woofer 2
(2, 1), (2, 2), (2, 3),
-- Woofer 3
(3, 4), (3, 5), (3, 6),
-- Woofer 4
(4, 7), (4, 8), (4, 9),
-- Woofer 5
(5, 2), (5, 6), (5, 10),
-- Woofer 6
(6, 1), (6, 5), (6, 8);