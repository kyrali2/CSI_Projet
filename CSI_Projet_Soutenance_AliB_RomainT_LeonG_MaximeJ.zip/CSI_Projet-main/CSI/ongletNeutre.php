<button class="menu-btn" onclick="toggleMenu()">☰</button>
<div class="sidebar">
    <ul class="menu">
        <li><a href="index.html">Accueil</a></li>
    </ul>
</div>