<button class="menu-btn" onclick="toggleMenu()">☰</button>
<div class="sidebar">
    <ul class="menu">
        <li><a href="accueilWoofer.php">Accueil Woofer</a></li>
        <li><a href="index.html">Accueil</a></li>
    </ul>
</div>