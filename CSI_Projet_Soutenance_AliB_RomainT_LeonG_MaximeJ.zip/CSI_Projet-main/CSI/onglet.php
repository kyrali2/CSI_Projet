<button class="menu-btn" onclick="toggleMenu()">☰</button>
<div class="sidebar">
    <ul class="menu">
        <li><a href="index.html">Accueil</a></li>
        <li><a href="tableauDeBord.php">Tableau de bord (responsable)</a></li>
        <li><a href="accueilWoofer.php">Accueil woofer</a></li>
    </ul>
</div>