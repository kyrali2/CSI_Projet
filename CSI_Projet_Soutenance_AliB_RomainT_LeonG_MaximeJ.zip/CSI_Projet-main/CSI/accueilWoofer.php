<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord</title>
    <link rel="stylesheet" href="css/onglet.css">
    <link rel="stylesheet" href="css/accueilWoofer.css">
</head>
<body>

    <?php include 'ongletNeutre.php'; ?>
<body>
    <h1>Accueil Woofer</h1>
    <button class="button" onclick="window.location.href='stock.php'">Gestion des stocks</button>
    <button class="button" onclick="window.location.href='vente.php'">Gestion des ventes</button>
</body>
<script src="js/onglet.js"></script>
</html>
